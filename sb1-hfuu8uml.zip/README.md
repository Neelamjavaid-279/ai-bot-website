# AI Job Application Bot

A production-ready AI-powered job application automation system with real email sending capabilities.

## Features

- **Advanced Job Matching**: Multi-factor algorithm analyzing skills, experience, location, and company fit
- **AI Content Generation**: Personalized cover letters and application emails
- **Real Email Sending**: Integration with EmailJS for actual email delivery
- **Application Tracking**: Monitor application status and success metrics
- **Responsive Design**: Optimized for all devices with modern UI/UX

## Email Setup

To enable real email sending functionality:

1. **Create EmailJS Account**
   - Visit [EmailJS.com](https://www.emailjs.com/) and create a free account
   - Set up an email service (Gmail, Outlook, etc.)

2. **Create Email Template**
   Create a template with these variables:
   ```
   {{to_email}} - Recipient email
   {{to_name}} - Recipient name
   {{from_name}} - Sender name
   {{from_email}} - Sender email
   {{subject}} - Email subject
   {{message}} - Email body
   {{cover_letter}} - Cover letter content
   {{job_title}} - Job position
   {{company_name}} - Company name
   ```

3. **Configure in App**
   - Click the settings icon in the Email Configuration section
   - Enter your Template ID and Public Key
   - Save the configuration

## Usage

1. **Select Candidate**: Choose from the available candidate profiles
2. **Browse Jobs**: Review AI-sourced job opportunities with match scores
3. **Generate Application**: Use AI to create personalized cover letters and emails
4. **Send Application**: Directly send emails to hiring managers

## Technical Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Email Service**: EmailJS
- **Build Tool**: Vite

## Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Configuration

The app uses EmailJS for email sending. Configure your credentials in the Email Configuration section of the app.

## Demo Data

The application includes realistic demo data for:
- 3 candidate profiles with detailed backgrounds
- 9 job opportunities across different industries
- Advanced matching algorithms
- Contact intelligence simulation

## Production Deployment

The app is production-ready and can be deployed to any static hosting service like Netlify, Vercel, or AWS S3.