import React, { useState } from 'react';
import { Settings, Mail, Key, Save, AlertCircle, CheckCircle } from 'lucide-react';

interface EmailSetupProps {
  onConfigSave: (config: EmailConfig) => void;
  currentConfig?: EmailConfig;
  selectedCandidate?: any;
}

export interface EmailConfig {
  templateId: string;
  publicKey: string;
}

export default function EmailSetup({ onConfigSave, currentConfig, selectedCandidate }: EmailSetupProps) {
  const [config, setConfig] = useState<EmailConfig>(
    currentConfig || {
      templateId: '',
      publicKey: ''
    }
  );
  const [showSetup, setShowSetup] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    if (config.templateId && config.publicKey) {
      onConfigSave(config);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    }
  };

  const isConfigComplete = config.templateId && config.publicKey;

  return (
    <div className="bg-white p-4 rounded-xl shadow-lg border border-gray-100 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Mail className="w-5 h-5 text-blue-500" />
          <h3 className="font-semibold text-gray-800">Email Configuration</h3>
          {isConfigComplete ? (
            <CheckCircle className="w-4 h-4 text-green-500" />
          ) : (
            <AlertCircle className="w-4 h-4 text-orange-500" />
          )}
        </div>
        <button
          onClick={() => setShowSetup(!showSetup)}
          className="p-2 text-gray-500 hover:text-blue-600 transition-colors"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>

      {!isConfigComplete && (
        <div className="bg-orange-50 border border-orange-200 p-3 rounded-lg mb-4">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
            <div className="text-sm">
              <p className="text-orange-800 font-medium">EmailJS Setup Required</p>
              <p className="text-orange-700 mt-1">
                Configure EmailJS to enable real email sending. 
                <a 
                  href="https://www.emailjs.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-orange-600 underline hover:text-orange-800 ml-1"
                >
                  Get your free EmailJS account here
                </a>
              </p>
            </div>
          </div>
        </div>
      )}

      {showSetup && (
        <div className="space-y-4 border-t border-gray-200 pt-4">
          <div className="bg-green-50 border border-green-200 p-3 rounded-lg">
            <div className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm">
                <p className="text-green-800 font-medium">Service ID Auto-Configured</p>
                {selectedCandidate && (
                  <p className="text-green-700 mt-1">
                    Using service ID: <code className="bg-green-100 px-1 rounded text-xs">{selectedCandidate.emailServiceId}</code> for {selectedCandidate.name}
                  </p>
                )}
              </div>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Template ID
            </label>
            <input
              type="text"
              value={config.templateId}
              onChange={(e) => setConfig(prev => ({ ...prev, templateId: e.target.value }))}
              placeholder="template_xxxxxxx"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Public Key
            </label>
            <input
              type="text"
              value={config.publicKey}
              onChange={(e) => setConfig(prev => ({ ...prev, publicKey: e.target.value }))}
              placeholder="Your EmailJS Public Key"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm bg-gray-50"
            />
            <p className="text-xs text-gray-500 mt-1">Find this in your EmailJS dashboard under Account settings</p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={handleSave}
              disabled={!isConfigComplete}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed text-sm font-medium"
            >
              <Save className="w-4 h-4" />
              Save Configuration
            </button>
            
            {saved && (
              <div className="flex items-center gap-1 text-green-600 text-sm">
                <CheckCircle className="w-4 h-4" />
                Saved!
              </div>
            )}
          </div>

          <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg">
            <h4 className="font-medium text-blue-800 mb-2">Setup Instructions:</h4>
            <ol className="text-sm text-blue-700 space-y-1 list-decimal list-inside">
              <li>Create a free account at <a href="https://www.emailjs.com/" target="_blank" rel="noopener noreferrer" className="underline">EmailJS.com</a></li>
              <li>Email service is already configured for this candidate</li>
              <li>Create an email template with variables: to_email, from_email, from_name, subject, message, cover_letter, job_title, company_name</li>
              <li>Copy your Template ID here (Public Key is pre-configured)</li>
            </ol>
          </div>
        </div>
      )}
    </div>
  );
}