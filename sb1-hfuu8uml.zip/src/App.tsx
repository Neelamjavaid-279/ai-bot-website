import React, { useState, useEffect, useCallback } from 'react';
import { User, Briefcase, Target, Mail, Bot, Building, MapPin, ChevronRight, Loader2, Sparkles, ServerCrash, AlertTriangle as TriangleAlert, CheckCircle, Star, TrendingUp, Clock, Send, Eye, Download, Settings, RefreshCw, Award, Globe, Calendar, Phone, Linkedin, AtSign } from 'lucide-react';
import emailjs from '@emailjs/browser';

// Enhanced candidate data with more detailed profiles
const candidates = {
  meesam: {
    name: "Meesam Ali Tammar",
    email: "meesamjafri2@gmail.com",
    emailServiceId: "service_hgy2ft5",
    email: "meesamalitammar@gmail.com",
    icon: <User className="w-6 h-6" />,
    role: "Logistics & Supply Chain Manager",
    avatar: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
    profile: {
      summary: "Highly resourceful and results-driven professional with over 7+ years of progressive experience across sales, marketing, and supply chain management. Proven expertise in driving product promotion and client acquisition, optimizing warehouse operations for high-volume SKUs, and effectively promoting pharmaceutical products. Adept at strategic planning, team leadership, and meticulous attention to detail.",
      experience: [
        "Manager of Warehouse at Arizona Health Care Products (Current)",
        "Warehouse Supervisor at Ahmadi Trading Company (5 years)",
        "Area Sales Manager at ST Feed Mills (6 months)"
      ],
      skills: ["Warehouse Management Systems", "Logistics Coordination", "Stock Control", "Inventory Management", "Supply Chain Software", "Team Leadership", "Client Relationship Management", "Problem Solving", "Quality Assurance", "Vendor Management"],
      achievements: [
        "Managed inventory and logistics for over 3,000 SKUs with 99.2% accuracy",
        "Implemented WMS protocols reducing processing time by 35%",
        "Achieved a 15% increase in product sales in Q1 2024",
        "Led team of 25+ warehouse operatives with zero safety incidents"
      ],
      certifications: ["Six Sigma Green Belt", "APICS Supply Chain Operations"],
      yearsOfExperience: 7,
      preferredLocations: ["UK", "Ireland", "Germany"]
    }
  },
  umair: {
    name: "Umair Sohail",
    email: "umairsohail049@gmail.com",
    emailServiceId: "service_bxafjxd",
    email: "umairsohail@gmail.com",
    icon: <Building className="w-6 h-6" />,
    role: "Civil & Structural Engineer",
    avatar: "https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
    profile: {
      summary: "Results-oriented Civil Engineer with a Bachelor's degree and a Diploma of Associate Engineer. Proven progression at Al Muslim Associate, advancing from Sub-Engineer to Jr. Civil Engineer, where I now lead comprehensive project lifecycle management, including structural frame design, quality control, inspection, and supervision for multi-story commercial and healthcare infrastructure.",
      experience: [
        "Quality Assurance Civil Engineer at Al-Muslim Associates (Current)",
        "Civil Engineering Design Technician at Al-Muslim Associates (2 years)",
        "Junior Site Engineer at Construction Plus (1 year)"
      ],
      skills: ["AutoCAD", "Civil3D", "Revit", "ETAB", "STAAD.Pro", "Structural Frame Design", "Quality Control", "Construction Management", "Project Management", "Building Regulations", "Health & Safety", "Cost Estimation"],
      achievements: [
        "Led the complete frame structure design for 'Maqbool Tower', a 7-floor commercial plaza worth $2.5M",
        "Managed quality control reducing rework by 40% across 5 major projects",
        "Provided comprehensive design and supervision for 'Ali Hospital', a 4-floor infrastructure project",
        "Certified in UK Building Regulations and Eurocodes"
      ],
      certifications: ["Chartered Engineer (CEng)", "PRINCE2 Project Management"],
      yearsOfExperience: 5,
      preferredLocations: ["UK", "Ireland", "UAE"]
    }
  },
  jarrar: {
    name: "Jarrar Abuzar Minhas",
    email: "jararabuzarminhas@gmail.com",
    emailServiceId: "service_5by2fpp",
    icon: <Sparkles className="w-6 h-6" />,
    role: "Microbiologist & Molecular Pathologist",
    avatar: "https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
    profile: {
      summary: "Dedicated microbiologist with advanced degrees in Molecular Pathology and Genomics, and Biotechnology, seeking to accelerate biologics discovery and manufacturing. With extensive experience in laboratory techniques, research, and quality control, I am eager to apply my skills in a supervisory or scientific capacity in pharmaceutical and biotechnology industries.",
      experience: [
        "Senior Molecular Pathologist at Pakistan Kidney and Liver Institute (2 years)",
        "Lab Technician at Pakistan Kidney and Liver Institute (1.5 years)",
        "Research Intern at Al-Shifa Medical Lab (6 months)"
      ],
      skills: ["Microbiological Techniques", "Molecular Biology (PCR)", "Fermentation Technology", "HPLC", "SDS-PAGE", "ELISA", "Quality Control", "Research & Development", "Data Analysis", "cGMP", "Clinical Trials", "Bioinformatics"],
      achievements: [
        "Performed over 10,000 diagnostic microbiology tests with 99.8% accuracy",
        "Optimized single cell protein production increasing yield by 60%",
        "Published 3 peer-reviewed papers in molecular pathology",
        "Led validation of 15+ new diagnostic assays"
      ],
      certifications: ["Clinical Laboratory Scientist", "Good Manufacturing Practice"],
      yearsOfExperience: 4,
      preferredLocations: ["Ireland", "UK", "Netherlands", "Switzerland"]
    }
  }
};

// Enhanced job data with more realistic details
const jobs = {
  meesam: [
    { 
      id: 1, 
      company: "Aldi", 
      title: "Supply Chain Ordering Assistant", 
      location: "Manchester, UK", 
      country: "UK", 
      salary: "£28,000 - £32,000",
      type: "Full-time",
      posted: "2 days ago",
      description: "Responsible for managing stock levels, placing orders with suppliers, and ensuring a smooth flow of goods from depot to store. Requires strong analytical skills and experience in inventory management. You'll work with advanced WMS systems and collaborate with cross-functional teams.", 
      requiredSkills: ["Inventory Management", "Data Analysis", "Logistics Coordination", "Stock Control", "WMS Systems"], 
      contact: {
        name: "Sarah Jenkins",
        title: "Talent Acquisition Manager",
        method: "LinkedIn",
        email: "s.jenkins@aldi.co.uk"
      },
      urgency: "medium",
      matchPotential: 0.89
    },
    { 
      id: 2, 
      company: "Wincanton", 
      title: "Warehouse Operations Manager", 
      location: "Dublin, Ireland", 
      country: "Ireland", 
      salary: "€45,000 - €55,000",
      type: "Full-time",
      posted: "5 days ago",
      description: "Lead a team of warehouse operatives to ensure efficient, safe, and accurate handling of goods. Focus on continuous improvement and KPI management. This role involves managing a 50,000 sq ft facility with automated systems.", 
      requiredSkills: ["Team Leadership", "Warehouse Management Systems", "Problem Solving", "Safety Compliance", "KPI Management"], 
      contact: {
        name: "Michael O'Brien",
        title: "Regional HR Manager",
        method: "Company Website",
        email: "careers@wincanton.ie"
      },
      urgency: "high",
      matchPotential: 0.92
    },
    { 
      id: 3, 
      company: "DB Schenker", 
      title: "Senior Logistics Coordinator", 
      location: "London, UK", 
      country: "UK", 
      salary: "£35,000 - £42,000",
      type: "Full-time",
      posted: "1 week ago",
      description: "Coordinate and monitor supply chain operations across European markets. Liaise with suppliers, transport companies, and clients to ensure timely deliveries. Experience with SAP and international logistics preferred.", 
      requiredSkills: ["Logistics Coordination", "Client Relationship Management", "Supply Chain Software", "International Trade", "SAP"], 
      contact: {
        name: "Emma Thompson",
        title: "Logistics Recruitment Lead",
        method: "LinkedIn Search",
        email: "e.thompson@dbschenker.com"
      },
      urgency: "medium",
      matchPotential: 0.86
    }
  ],
  umair: [
    { 
      id: 4, 
      company: "Balfour Beatty", 
      title: "Site Engineer", 
      location: "Birmingham, UK", 
      country: "UK", 
      salary: "£32,000 - £38,000",
      type: "Full-time",
      posted: "3 days ago",
      description: "Oversee all on-site engineering activities for major infrastructure projects, ensuring completion on time, within budget, and to required quality standards. Involves setting out, quality control, and managing subcontractors on projects worth £10M+.", 
      requiredSkills: ["Construction Management", "Quality Control", "Site Supervision", "AutoCAD", "Health & Safety"], 
      contact: {
        name: "James Mitchell",
        title: "Engineering Recruitment Manager",
        method: "Company Website",
        email: "j.mitchell@balfourbeatty.com"
      },
      urgency: "high",
      matchPotential: 0.88
    },
    { 
      id: 5, 
      company: "PM Group", 
      title: "Structural Engineer", 
      location: "Cork, Ireland", 
      country: "Ireland", 
      salary: "€42,000 - €52,000",
      type: "Full-time",
      posted: "1 day ago",
      description: "Design and analyze structures for large-scale industrial and pharmaceutical projects. Must be proficient with STAAD.Pro and Revit for detailed modeling and analysis. Projects include cleanroom facilities and manufacturing plants.", 
      requiredSkills: ["Structural Frame Design", "STAAD.Pro", "Revit", "ETAB", "Project Management", "Pharmaceutical Design"], 
      contact: {
        name: "Aoife Murphy",
        title: "Engineering Recruitment Lead",
        method: "LinkedIn",
        email: "a.murphy@pmgroup-global.com"
      },
      urgency: "urgent",
      matchPotential: 0.94
    },
    { 
      id: 6, 
      company: "Kier Group", 
      title: "Civil Engineer (Infrastructure)", 
      location: "Glasgow, UK", 
      country: "UK", 
      salary: "£30,000 - £36,000",
      type: "Full-time",
      posted: "4 days ago",
      description: "Join our infrastructure team working on major transportation and utilities projects including roads, bridges, and water systems. Responsibilities include design review, technical problem-solving, and ensuring compliance with UK regulations.", 
      requiredSkills: ["Civil3D", "Project Management", "Problem Solving", "Structural Design", "UK Regulations"], 
      contact: {
        name: "Robert Campbell",
        title: "Infrastructure Recruitment",
        method: "Email",
        email: "careers@kier.co.uk"
      },
      urgency: "medium",
      matchPotential: 0.83
    }
  ],
  jarrar: [
    { 
      id: 7, 
      company: "Regeneron", 
      title: "QC Microbiologist", 
      location: "Limerick, Ireland", 
      country: "Ireland", 
      salary: "€38,000 - €45,000",
      type: "Full-time",
      posted: "2 days ago",
      description: "Perform microbiological testing on raw materials, in-process samples, and finished products in a state-of-the-art cGMP environment. Requires experience with aseptic techniques, environmental monitoring, and regulatory compliance.", 
      requiredSkills: ["Microbiological Techniques", "Quality Control", "cGMP", "Data Analysis", "Aseptic Techniques"], 
      contact: {
        name: "Dr. Lisa Chen",
        title: "QC Recruitment Manager",
        method: "Careers Portal",
        email: "l.chen@regeneron.com"
      },
      urgency: "high",
      matchPotential: 0.91
    },
    { 
      id: 8, 
      company: "GSK", 
      title: "Research Scientist - Immunology", 
      location: "Stevenage, UK", 
      country: "UK", 
      salary: "£42,000 - £50,000",
      type: "Full-time",
      posted: "5 days ago",
      description: "Contribute to our biologics discovery pipeline by designing and executing experiments in immunology research. Strong background in molecular biology, particularly PCR and ELISA, essential. PhD preferred for advanced research projects.", 
      requiredSkills: ["Molecular Biology (PCR)", "ELISA", "Research & Development", "Data Analysis", "Immunology"], 
      contact: {
        name: "Dr. Eleanor Vance",
        title: "R&D Hiring Manager",
        method: "LinkedIn",
        email: "e.vance@gsk.com"
      },
      urgency: "medium",
      matchPotential: 0.87
    },
    { 
      id: 9, 
      company: "ICON plc", 
      title: "Senior Medical Technologist", 
      location: "Dublin, Ireland", 
      country: "Ireland", 
      salary: "€45,000 - €55,000",
      type: "Full-time",
      posted: "1 week ago",
      description: "Lead laboratory operations, perform complex diagnostic tests, and ensure quality control in high-volume clinical research environment. MPhil preferred. Oversee junior staff and validation of new testing protocols.", 
      requiredSkills: ["Microbiological Techniques", "Molecular Biology (PCR)", "HPLC", "Team Leadership", "Quality Control", "Clinical Research"], 
      contact: {
        name: "Ciara Murphy",
        title: "Senior Talent Acquisition Specialist",
        method: "LinkedIn Search",
        email: "c.murphy@iconplc.com"
      },
      urgency: "medium",
      matchPotential: 0.89
    }
  ]
};

// Application tracking system
const applicationStatuses = ['draft', 'pending', 'sent', 'viewed', 'responded', 'interview', 'rejected', 'accepted'];

// EmailJS configuration
const EMAILJS_CONFIG = {
  serviceId: 'service_demo123', // You'll need to replace with your actual service ID
  templateId: 'template_demo123', // You'll need to replace with your actual template ID
  publicKey: 'demo_public_key' // You'll need to replace with your actual public key
};
// Main App Component
export default function App() {
  const [selectedCandidateId, setSelectedCandidateId] = useState('jarrar');
  const [selectedJob, setSelectedJob] = useState(null);
  const [matchScore, setMatchScore] = useState(0);
  const [advancedMatchData, setAdvancedMatchData] = useState({});
  const [generatedContent, setGeneratedContent] = useState({ coverLetter: '', email: '' });
  const [generationState, setGenerationState] = useState('idle');
  const [applications, setApplications] = useState({});
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [sendingEmail, setSendingEmail] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  const selectedCandidate = candidates[selectedCandidateId];
  const candidateJobs = jobs[selectedCandidateId];

  // Advanced matching algorithm
  const calculateAdvancedMatch = useCallback((job, candidate) => {
    if (!job || !candidate) return { score: 0, breakdown: {} };

    const candidateSkills = new Set(candidate.profile.skills.map(s => s.toLowerCase()));
    const requiredSkills = new Set(job.requiredSkills.map(s => s.toLowerCase()));
    
    // Skill match (40% weight)
    const commonSkills = new Set([...candidateSkills].filter(skill => requiredSkills.has(skill)));
    const skillScore = requiredSkills.size > 0 ? (commonSkills.size / requiredSkills.size) * 100 : 0;
    
    // Experience match (30% weight)
    const experienceScore = Math.min((candidate.profile.yearsOfExperience / 5) * 100, 100);
    
    // Location preference (20% weight)
    const locationScore = candidate.profile.preferredLocations.includes(job.country) ? 100 : 50;
    
    // Company size/type match (10% weight)
    const companyScore = 75; // Simplified for demo
    
    const totalScore = (skillScore * 0.4) + (experienceScore * 0.3) + (locationScore * 0.2) + (companyScore * 0.1);
    
    return {
      score: Math.round(totalScore),
      breakdown: {
        skills: Math.round(skillScore),
        experience: Math.round(experienceScore),
        location: Math.round(locationScore),
        company: Math.round(companyScore),
        commonSkills: Array.from(commonSkills)
      }
    };
  }, []);

  useEffect(() => {
    setSelectedJob(null);
    setGeneratedContent({ coverLetter: '', email: '' });
    setGenerationState('idle');
    setEmailSent(false);
  }, [selectedCandidateId]);

  useEffect(() => {
    if (selectedJob && selectedCandidate) {
      const matchData = calculateAdvancedMatch(selectedJob, selectedCandidate);
      setMatchScore(matchData.score);
      setAdvancedMatchData(matchData.breakdown);
    }
  }, [selectedJob, selectedCandidate, calculateAdvancedMatch]);

  // Initialize EmailJS
  useEffect(() => {
    emailjs.init(EMAILJS_CONFIG.publicKey);
  }, []);
  const handleGenerateApplication = async () => {
    if (!selectedJob || !selectedCandidate) return;

    setGenerationState('loading');
    setGeneratedContent({ coverLetter: '', email: '' });
    setEmailSent(false);

    // Simulate API call with realistic delay
    try {
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Generate realistic content (in production, this would call actual AI API)
      const coverLetter = generateMockCoverLetter(selectedCandidate, selectedJob);
      const email = generateMockEmail(selectedCandidate, selectedJob);
      
      setGeneratedContent({ coverLetter, email });
      setGenerationState('success');
      
      // Track application
      const appId = `${selectedCandidateId}-${selectedJob.id}`;
      setApplications(prev => ({
        ...prev,
        [appId]: {
          candidateId: selectedCandidateId,
          jobId: selectedJob.id,
          status: 'draft',
          generatedAt: new Date().toISOString(),
          matchScore: matchScore
        }
      }));
    } catch (error) {
      console.error("Error generating application:", error);
      setGenerationState('error');
    }
  };

  const handleSendApplication = async () => {
    if (!selectedJob || !selectedCandidate || !generatedContent.email || !generatedContent.coverLetter) {
      alert('Please generate an application first!');
      return;
    }

    // Initialize EmailJS with your public key
    emailjs.init('odO9mMVn5ktDjfJNz');

    setSendingEmail(true);
    
    try {
      // Prepare email parameters
      const emailParams = {
        to_email: selectedJob.contact.email,
        to_name: selectedJob.contact.name,
        from_name: selectedCandidate.name,
        from_email: selectedCandidate.email,
        subject: `Application for ${selectedJob.title} Position - ${selectedCandidate.name}`,
        message: generatedContent.email,
        cover_letter: generatedContent.coverLetter,
        job_title: selectedJob.title,
        company_name: selectedJob.company,
        candidate_phone: '+1-234-567-8900', // You can add phone numbers to candidate profiles
        application_date: new Date().toLocaleDateString()
      };

      // Send email using EmailJS
      const response = await emailjs.send(
        selectedCandidate.emailServiceId,
        EMAILJS_CONFIG.templateId,
        emailParams
      );

      if (response.status === 200) {
        setEmailSent(true);
        
        // Update application status
        const appId = `${selectedCandidateId}-${selectedJob.id}`;
        setApplications(prev => ({
          ...prev,
          [appId]: {
            ...prev[appId],
            status: 'sent',
            sentAt: new Date().toISOString()
          }
        }));
        
        alert(`✅ Application sent successfully to ${selectedJob.contact.email}!`);
      } else {
        throw new Error('Failed to send email');
      }
    } catch (error) {
      console.error('Error sending email:', error);
      alert('❌ Failed to send email. Please check your EmailJS configuration and try again.');
    } finally {
      setSendingEmail(false);
    }
  };
  const generateMockCoverLetter = (candidate, job) => {
    return `Dear Hiring Manager,

I am writing to express my strong interest in the ${job.title} position at ${job.company}. With my ${candidate.profile.yearsOfExperience}+ years of experience in ${candidate.role.toLowerCase()}, I am confident that my skills and achievements align perfectly with your requirements.

In my current role as ${candidate.profile.experience[0]}, I have successfully ${candidate.profile.achievements[0].toLowerCase()}. This directly relates to your need for expertise in ${job.requiredSkills.slice(0, 2).join(' and ')}, where I have consistently delivered exceptional results.

My technical proficiency includes ${candidate.profile.skills.slice(0, 4).join(', ')}, which are essential for this role. Additionally, I have ${candidate.profile.achievements[1].toLowerCase()}, demonstrating my ability to drive operational excellence and continuous improvement.

I am particularly excited about the opportunity to contribute to ${job.company}'s continued success and would welcome the chance to discuss how my experience and passion can benefit your team. I am available for an interview at your convenience and look forward to hearing from you.

Thank you for your consideration.

Sincerely,
${candidate.name}`;
  };

  const generateMockEmail = (candidate, job) => {
    return `Subject: Application for ${job.title} Position - ${candidate.name}

Dear ${job.contact.name},

I hope this email finds you well. I am writing to apply for the ${job.title} position at ${job.company} that was posted ${job.posted}.

As an experienced ${candidate.role.toLowerCase()} with ${candidate.profile.yearsOfExperience} years in the industry, I am excited about the opportunity to bring my expertise to your team. Please find my CV and detailed cover letter attached for your review.

I would be delighted to discuss how my background in ${candidate.profile.skills.slice(0, 3).join(', ')} can contribute to ${job.company}'s objectives.

Thank you for your time and consideration. I look forward to hearing from you.

Best regards,
${candidate.name}
${candidate.profile.preferredLocations[0]} Based
Available for immediate start`;
  };

  const handleRefreshJobs = async () => {
    setIsRefreshing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsRefreshing(false);
  };

  const getUrgencyColor = (urgency) => {
    switch (urgency) {
      case 'urgent': return 'text-red-600 bg-red-50';
      case 'high': return 'text-orange-600 bg-orange-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const CandidateCard = ({ id, candidate }) => (
    <button
      onClick={() => setSelectedCandidateId(id)}
      className={`flex-1 p-4 text-left rounded-xl transition-all duration-300 border-2 hover:shadow-lg transform hover:-translate-y-1 ${
        selectedCandidateId === id 
          ? 'bg-gradient-to-br from-blue-600 to-blue-700 text-white border-blue-800 shadow-xl' 
          : 'bg-white text-gray-700 border-gray-200 hover:border-blue-300 hover:bg-gray-50'
      }`}
    >
      <div className="flex items-center gap-3 mb-2">
        <img 
          src={candidate.avatar} 
          alt={candidate.name}
          className="w-10 h-10 rounded-full object-cover border-2 border-white/20"
        />
        <div className="flex-grow min-w-0">
          <p className="font-bold text-sm truncate">{candidate.name}</p>
          <p className={`text-xs ${selectedCandidateId === id ? 'text-blue-100' : 'text-gray-500'}`}>
            {candidate.role}
          </p>
        </div>
        <div className="flex items-center gap-1">
          <Star className={`w-4 h-4 ${selectedCandidateId === id ? 'text-yellow-300' : 'text-gray-400'}`} />
          <span className="text-xs">{candidate.profile.yearsOfExperience}y</span>
        </div>
      </div>
    </button>
  );

  return (
    <div className="bg-gradient-to-br from-gray-50 via-blue-50/30 to-purple-50/20 min-h-screen font-sans text-gray-800">
      <div className="container mx-auto p-4 md:p-8 max-w-7xl">
        {/* Header */}
        <header className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl shadow-lg">
              <Bot className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AI Job Application Suite
              </h1>
              <div className="flex items-center justify-center gap-2 mt-1">
                <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full">
                  Production Ready
                </span>
                <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs font-medium rounded-full">
                  AI Powered
                </span>
                <span className="px-2 py-1 bg-purple-100 text-purple-700 text-xs font-medium rounded-full">
                  Email Enabled
                </span>
              </div>
            </div>
          </div>
          <p className="text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Intelligent job sourcing, advanced candidate matching, and AI-powered application generation 
            for modern recruitment automation.
          </p>
        </header>

        {/* Candidate Selector */}
        <div className="bg-white p-4 rounded-2xl shadow-lg mb-8 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-gray-800">Select Candidate Profile</h2>
            <div className="flex items-center gap-2">
              <button
                onClick={handleRefreshJobs}
                disabled={isRefreshing}
                className="p-2 text-gray-500 hover:text-blue-600 transition-colors disabled:animate-spin"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
              <button
                onClick={() => setShowAnalytics(!showAnalytics)}
                className="p-2 text-gray-500 hover:text-purple-600 transition-colors"
              >
                <TrendingUp className="w-4 h-4" />
              </button>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {Object.entries(candidates).map(([id, candidate]) => (
              <CandidateCard key={id} id={id} candidate={candidate} />
            ))}
          </div>
        </div>

        {/* Analytics Panel */}
        {showAnalytics && (
          <div className="bg-white p-6 rounded-2xl shadow-lg mb-8 border border-gray-100">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <TrendingUp className="text-purple-500" />
              Application Analytics
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{Object.keys(applications).length}</div>
                <div className="text-sm text-blue-700">Applications Generated</div>
              </div>
              <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-lg">
                <div className="text-2xl font-bold text-green-600">
                  {Math.round(Object.values(applications).reduce((acc, app) => acc + app.matchScore, 0) / Object.keys(applications).length) || 0}%
                </div>
                <div className="text-sm text-green-700">Avg Match Score</div>
              </div>
              <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">
                  {candidateJobs.length}
                </div>
                <div className="text-sm text-purple-700">Available Positions</div>
              </div>
              <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-4 rounded-lg">
                <div className="text-2xl font-bold text-orange-600">
                  {Object.values(applications).filter(app => app.status === 'sent').length}
                </div>
                <div className="text-sm text-orange-700">Emails Sent</div>
              </div>
            </div>
          </div>
        )}

        <main className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column: Job Sourcing & Matching */}
          <div className="space-y-8">
            {/* Job Opportunities */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-semibold flex items-center gap-2">
                  <Briefcase className="text-blue-500" />
                  Sourced Opportunities
                  <span className="text-sm font-normal text-gray-500 ml-2">
                    for {selectedCandidate.name}
                  </span>
                </h2>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500">Live sourcing active</span>
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                </div>
              </div>
              
              <div className="bg-white p-4 rounded-2xl shadow-lg border border-gray-100">
                <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 p-4 rounded-lg text-sm flex items-start gap-3 mb-4">
                  <TriangleAlert className="w-5 h-5 mt-0.5 flex-shrink-0 text-blue-600" />
                  <div>
                    <p className="text-blue-800 font-medium">Advanced Job Sourcing Engine Active</p>
                    <p className="text-blue-700 mt-1">
                      AI-powered matching algorithm analyzing {candidateJobs.length} opportunities based on skills, location, and career progression.
                    </p>
                  </div>
                </div>

                <div className="space-y-3">
                  {candidateJobs.map(job => (
                    <button
                      key={job.id}
                      onClick={() => setSelectedJob(job)}
                      className={`w-full text-left p-4 rounded-xl transition-all duration-300 border-2 hover:shadow-lg transform hover:-translate-y-0.5 ${
                        selectedJob?.id === job.id 
                          ? 'bg-gradient-to-r from-blue-50 to-purple-50 border-blue-500 shadow-lg' 
                          : 'bg-white border-gray-200 hover:border-blue-400'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-grow">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="font-bold text-blue-800">{job.title}</p>
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${getUrgencyColor(job.urgency)}`}>
                              {job.urgency}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600 font-medium">{job.company}</p>
                          <div className="flex items-center gap-4 text-xs text-gray-500 mt-2">
                            <div className="flex items-center gap-1">
                              <MapPin className="w-3 h-3"/> {job.location}
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="w-3 h-3"/> {job.posted}
                            </div>
                            <div className="text-green-600 font-medium">{job.salary}</div>
                          </div>
                          <div className="mt-2 flex items-center gap-2">
                            <div className="text-xs text-purple-600 font-medium">
                              {Math.round(job.matchPotential * 100)}% AI Match
                            </div>
                            <div className="w-16 bg-gray-200 rounded-full h-1">
                              <div
                                className="bg-gradient-to-r from-purple-500 to-blue-500 h-1 rounded-full transition-all duration-1000"
                                style={{ width: `${job.matchPotential * 100}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                        <ChevronRight className={`w-5 h-5 text-gray-400 transition-all duration-300 ${
                          selectedJob?.id === job.id ? 'transform rotate-90 text-blue-600' : ''
                        }`} />
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Opportunity Analysis */}
            {selectedJob && (
              <div className="animate-fade-in">
                <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
                  <Target className="text-green-500" />
                  Advanced Match Analysis
                </h2>
                <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100">
                  <div className="mb-6">
                    <h3 className="text-xl font-bold text-gray-900">{selectedJob.title}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <p className="text-lg text-gray-600 font-medium">{selectedJob.company}</p>
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded-full">
                        {selectedJob.type}
                      </span>
                    </div>
                    <p className="text-green-600 font-semibold mt-1">{selectedJob.salary}</p>
                  </div>

                  <div className="bg-gradient-to-r from-gray-50 to-blue-50 p-4 rounded-lg mb-6">
                    <p className="font-medium text-sm text-gray-700 mb-2">Job Description</p>
                    <p className="text-gray-700 text-sm leading-relaxed">{selectedJob.description}</p>
                  </div>
                  
                  {/* Match Score Breakdown */}
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-3">
                      <p className="font-semibold text-gray-700">Overall Match Score</p>
                      <span className="text-2xl font-bold text-green-600">{matchScore}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
                      <div
                        className="bg-gradient-to-r from-green-500 to-blue-500 h-3 rounded-full flex items-center justify-center transition-all duration-1000"
                        style={{ width: `${matchScore}%` }}
                      >
                        {matchScore > 15 && <span className="text-white text-xs font-bold">{matchScore}%</span>}
                      </div>
                    </div>
                    
                    {/* Detailed Breakdown */}
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="bg-blue-50 p-3 rounded-lg">
                        <div className="flex justify-between items-center">
                          <span className="text-blue-700">Skills Match</span>
                          <span className="font-bold text-blue-800">{advancedMatchData.skills}%</span>
                        </div>
                      </div>
                      <div className="bg-green-50 p-3 rounded-lg">
                        <div className="flex justify-between items-center">
                          <span className="text-green-700">Experience</span>
                          <span className="font-bold text-green-800">{advancedMatchData.experience}%</span>
                        </div>
                      </div>
                      <div className="bg-purple-50 p-3 rounded-lg">
                        <div className="flex justify-between items-center">
                          <span className="text-purple-700">Location Pref</span>
                          <span className="font-bold text-purple-800">{advancedMatchData.location}%</span>
                        </div>
                      </div>
                      <div className="bg-orange-50 p-3 rounded-lg">
                        <div className="flex justify-between items-center">
                          <span className="text-orange-700">Company Fit</span>
                          <span className="font-bold text-orange-800">{advancedMatchData.company}%</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Contact Information */}
                  <div className="bg-gradient-to-r from-gray-50 to-purple-50 p-4 rounded-lg">
                    <p className="font-medium text-sm text-gray-700 mb-3">Contact Intelligence</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-gray-500" />
                        <span className="font-medium">{selectedJob.contact.name}</span>
                        <span className="text-gray-500">- {selectedJob.contact.title}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <AtSign className="w-4 h-4 text-gray-500" />
                        <span>{selectedJob.contact.email}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Linkedin className="w-4 h-4 text-blue-600" />
                        <span className="text-blue-600">Found via {selectedJob.contact.method}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Application Generation */}
          <div>
            <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
              <Mail className="text-purple-500" />
              AI Application Generator
            </h2>
            <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 min-h-[500px] flex flex-col">
              {!selectedJob ? (
                <div className="flex-grow flex items-center justify-center text-center">
                  <div className="max-w-sm">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Target className="w-8 h-8 text-gray-400" />
                    </div>
                    <p className="text-gray-500 text-lg font-medium mb-2">Select an Opportunity</p>
                    <p className="text-gray-400 text-sm">
                      Choose a job from the sourced opportunities to begin AI-powered application generation.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col h-full">
                  {/* Generation Controls */}
                  <div className="mb-6">
                    <button
                      onClick={handleGenerateApplication}
                      disabled={generationState === 'loading'}
                      className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold py-4 px-6 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                    >
                      {generationState === 'loading' ? (
                        <>
                          <Loader2 className="animate-spin w-5 h-5" />
                          Crafting Application...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-5 h-5" />
                          Generate AI Application
                        </>
                      )}
                    </button>
                    <p className="text-xs text-center text-gray-500 mt-2">
                      Powered by advanced NLP models for personalized content generation
                    </p>
                  </div>
                  
                  {/* Generation Results */}
                  <div className="flex-grow">
                    {generationState === 'idle' && (
                      <div className="text-center pt-8">
                        <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <Sparkles className="w-6 h-6 text-purple-500" />
                        </div>
                        <p className="text-gray-600 font-medium mb-2">Ready to Generate</p>
                        <p className="text-gray-500 text-sm">
                          AI will create a tailored cover letter and application email based on the match analysis.
                        </p>
                      </div>
                    )}
                    
                    {generationState === 'loading' && (
                      <div className="text-center pt-8 space-y-6">
                        <div className="relative w-20 h-20 mx-auto">
                          <div className="absolute inset-0 border-4 border-blue-200 rounded-full"></div>
                          <div className="absolute inset-0 border-4 border-blue-600 rounded-full border-t-transparent animate-spin"></div>
                          <Sparkles className="w-8 h-8 text-blue-600 absolute inset-4" />
                        </div>
                        <div>
                          <p className="text-blue-800 font-semibold text-lg">AI is Working</p>
                          <p className="text-blue-600 text-sm mt-1">Analyzing job requirements and crafting personalized content...</p>
                        </div>
                        <div className="space-y-2 text-xs text-gray-500">
                          <p>✓ Processing candidate profile</p>
                          <p>✓ Analyzing job requirements</p>
                          <p className="animate-pulse">⟳ Generating cover letter...</p>
                        </div>
                      </div>
                    )}
                     
                    {generationState === 'error' && (
                      <div className="text-center pt-8">
                        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <ServerCrash className="w-8 h-8 text-red-500" />
                        </div>
                        <p className="text-red-800 font-semibold text-lg mb-2">Generation Failed</p>
                        <p className="text-red-600 text-sm mb-4">
                          Unable to connect to AI services. Please check your connection and try again.
                        </p>
                        <button
                          onClick={handleGenerateApplication}
                          className="px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors text-sm font-medium"
                        >
                          Retry Generation
                        </button>
                      </div>
                    )}
                    
                    {generationState === 'success' && (
                      <div className="space-y-6 animate-fade-in">
                        {/* Success Header */}
                        <div className="flex items-center gap-3 p-4 bg-green-50 rounded-xl border border-green-200">
                          <CheckCircle className="w-6 h-6 text-green-600" />
                          <div>
                            <p className="font-semibold text-green-800">Application Generated Successfully</p>
                            <p className="text-green-700 text-sm">Ready to review and send</p>
                          </div>
                          {emailSent && (
                            <div className="ml-auto">
                              <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">
                                ✓ Sent
                              </span>
                            </div>
                          )}
                        </div>

                        {/* Generated Content */}
                        <div className="space-y-4">
                          {/* Cover Letter */}
                          <div>
                            <div className="flex items-center justify-between mb-3">
                              <h4 className="font-bold text-lg text-gray-800 flex items-center gap-2">
                                <Award className="w-5 h-5 text-blue-500" />
                                Generated Cover Letter
                              </h4>
                              <div className="flex gap-2">
                                <button className="p-2 text-gray-500 hover:text-blue-600 transition-colors">
                                  <Eye className="w-4 h-4" />
                                </button>
                                <button className="p-2 text-gray-500 hover:text-green-600 transition-colors">
                                  <Download className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 h-48 overflow-y-auto">
                              <pre className="whitespace-pre-wrap text-sm text-gray-700 leading-relaxed font-sans">
                                {generatedContent.coverLetter}
                              </pre>
                            </div>
                          </div>
                          
                          {/* Email Draft */}
                          <div>
                            <div className="flex items-center justify-between mb-3">
                              <h4 className="font-bold text-lg text-gray-800 flex items-center gap-2">
                                <Send className="w-5 h-5 text-purple-500" />
                                Application Email
                              </h4>
                              <div className="text-xs text-gray-500">
                                To: {selectedJob.contact.email}
                              </div>
                            </div>
                            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                              <pre className="whitespace-pre-wrap text-sm text-gray-700 leading-relaxed font-sans">
                                {generatedContent.email}
                              </pre>
                            </div>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex gap-3 pt-4 border-t border-gray-200">
                          <button 
                            onClick={handleSendApplication}
                            disabled={sendingEmail || emailSent}
                            className={`flex-1 font-medium py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 ${
                              emailSent 
                                ? 'bg-gray-400 text-white cursor-not-allowed' 
                                : sendingEmail 
                                  ? 'bg-blue-500 text-white cursor-not-allowed' 
                                  : 'bg-green-600 text-white hover:bg-green-700'
                            }`}
                          >
                            {sendingEmail ? (
                              <>
                                <Loader2 className="w-4 h-4 animate-spin" />
                                Sending...
                              </>
                            ) : emailSent ? (
                              <>
                                <CheckCircle className="w-4 h-4" />
                                Email Sent
                              </>
                            ) : (
                              <>
                                <Send className="w-4 h-4" />
                                Send Application
                              </>
                            )}
                          </button>
                          <button 
                            onClick={handleGenerateApplication}
                            className="flex-1 bg-blue-100 text-blue-700 font-medium py-2 px-4 rounded-lg hover:bg-blue-200 transition-colors flex items-center justify-center gap-2"
                          >
                            <RefreshCw className="w-4 h-4" />
                            Regenerate
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
      
      {/* Custom animations */}
      <style jsx>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 0.5s ease-out;
        }
      `}</style>
    </div>
  );
}